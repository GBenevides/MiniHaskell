package br.unb.cic.mh;

public enum Tipo {
	BOOLEANO,
	INTEIRO,
	ERRO;
}
