package br.unb.cic.mh;

public interface Valor extends Expressao {

}
